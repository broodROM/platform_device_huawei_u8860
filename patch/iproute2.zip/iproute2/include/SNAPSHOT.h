static const char SNAPSHOT[] = "120521";
